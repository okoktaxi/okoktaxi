import React, { useEffect } from 'react';
import { useParams, Navigate, Link } from 'react-router-dom';
import { cities } from '../constants/cities';
import BookingForm from '../components/BookingForm';
import { Phone, MessageCircle, ShieldCheck, MapPin, Star, Car, Zap, Award, ChevronRight } from 'lucide-react';
import { motion } from 'motion/react';

export default function CityPage() {
  const { citySlug } = useParams();
  const city = cities.find(c => c.slug === citySlug?.replace('-taxi', ''));

  useEffect(() => {
    if (city) {
      document.title = city.title;
      const metaDescription = document.querySelector('meta[name="description"]');
      if (metaDescription) {
        metaDescription.setAttribute('content', city.description);
      }
      const metaKeywords = document.querySelector('meta[name="keywords"]');
      if (metaKeywords) {
        metaKeywords.setAttribute('content', city.keywords.join(', '));
      }
      window.scrollTo(0, 0);
    }
  }, [city]);

  if (!city) {
    return <Navigate to="/" />;
  }

  return (
    <div className="flex flex-col min-h-screen">
      {/* City Hero Section */}
      <section className="relative min-h-[500px] flex items-center bg-black overflow-hidden">
        <div className="absolute inset-0 opacity-40">
          <img 
            src={`https://picsum.photos/seed/${city.slug}/1920/1080`} 
            alt={`${city.name} Taxi Service`} 
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
        </div>
        <div className="absolute inset-0 bg-gradient-to-r from-black via-black/80 to-transparent"></div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 py-12">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-white"
            >
              <div className="inline-flex items-center gap-2 bg-amber-400/20 border border-amber-400/30 px-3 py-1 rounded-full text-amber-400 text-xs font-bold uppercase tracking-wider mb-6">
                <MapPin className="h-3 w-3" /> 24/7 Service in {city.name}
              </div>
              <h1 className="text-4xl sm:text-5xl font-bold font-display leading-tight mb-6">
                Best <span className="text-amber-400">{city.name} Taxi Service</span> – Fast & Reliable
              </h1>
              <p className="text-lg text-gray-300 mb-8 max-w-lg">
                Looking for a <strong>call taxi in {city.name}</strong>? Book your ride with OKOK Taxi for airport drops, outstation trips, and local rentals at the best prices.
              </p>
              <div className="flex flex-wrap gap-4">
                <a 
                  href="tel:8608199000" 
                  className="bg-amber-400 text-black px-6 py-3 rounded-xl font-bold flex items-center gap-2 hover:bg-amber-500 transition-all shadow-lg"
                >
                  <Phone className="h-5 w-5" /> Call {city.name} Taxi
                </a>
              </div>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="w-full max-w-md mx-auto lg:ml-auto"
            >
              <BookingForm />
            </motion.div>
          </div>
        </div>
      </section>

      {/* Local SEO Content Section */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            <div className="lg:col-span-2">
              <h2 className="text-3xl font-bold text-gray-900 mb-6">Trusted <span className="text-amber-500">Cab Services in {city.name}</span></h2>
              <div className="prose prose-amber max-w-none text-gray-600 space-y-4">
                <p>
                  OKOK Taxi is the leading provider of <strong>{city.name} taxi service</strong>, offering a wide range of travel solutions for residents and visitors alike. 
                  Whether you are searching for a <strong>call taxi near me</strong> in {city.name} or need a reliable <strong>outstation taxi</strong> for a long trip, we are here to serve you 24/7.
                </p>
                <p>
                  Our <strong>{city.name} cab booking</strong> system is designed for your convenience. With a fleet of well-maintained Sedans, SUVs, and Innovas, we ensure a comfortable journey every time. 
                  We specialize in <strong>one way taxi</strong> drops and <strong>round trip</strong> packages that are easy on your pocket.
                </p>
                <h3 className="text-xl font-bold text-gray-800 mt-8 mb-4">Why Book with OKOK Taxi {city.name}?</h3>
                <ul className="grid grid-cols-1 md:grid-cols-2 gap-4 list-none p-0">
                  {[
                    "Fast pickup within 10-15 minutes",
                    "Professional & police-verified drivers",
                    "No surge pricing - transparent billing",
                    "Clean and sanitized vehicles",
                    "24/7 customer support line",
                    "Special discounts for hospital trips"
                  ].map((item, i) => (
                    <li key={i} className="flex items-start gap-3 bg-gray-50 p-3 rounded-lg border border-gray-100">
                      <ShieldCheck className="h-5 w-5 text-green-500 mt-0.5 flex-shrink-0" />
                      <span className="text-sm font-medium">{item}</span>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
            
            <div className="bg-gray-50 p-8 rounded-2xl border border-gray-200 h-fit">
              <h3 className="text-xl font-bold text-gray-900 mb-6">Popular {city.name} Routes</h3>
              <ul className="space-y-4">
                {[
                  `${city.name} to Airport Drop`,
                  `${city.name} to Pondicherry Taxi`,
                  `${city.name} to Bangalore Outstation`,
                  `${city.name} Local 8hrs/80km Rental`,
                  `${city.name} One Way Drop Taxi`
                ].map((route, i) => (
                  <li key={i} className="flex items-center justify-between group cursor-pointer border-b border-gray-200 pb-3 last:border-0">
                    <span className="text-sm text-gray-700 group-hover:text-amber-600 transition-colors">{route}</span>
                    <ChevronRight className="h-4 w-4 text-gray-400 group-hover:text-amber-600" />
                  </li>
                ))}
              </ul>
              <div className="mt-8 pt-8 border-t border-gray-200">
                <p className="text-xs text-gray-500 mb-4 uppercase font-bold tracking-widest">Target Keywords</p>
                <div className="flex flex-wrap gap-2">
                  {city.keywords.slice(0, 10).map((kw, i) => (
                    <span key={i} className="bg-white px-2 py-1 rounded border border-gray-200 text-[10px] text-gray-400">
                      {kw}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Fleet & Pricing Section */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900">Affordable <span className="text-amber-500">{city.name} Taxi Fare</span></h2>
            <p className="text-gray-600 mt-2">Best rates for all vehicle types in {city.name}</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { type: "Sedan", price: "₹12/km", icon: Car, desc: "Perfect for city rides" },
              { type: "SUV", price: "₹16/km", icon: Car, desc: "Ideal for family trips" },
              { type: "Innova", price: "₹18/km", icon: Car, desc: "Premium travel comfort" }
            ].map((item, i) => (
              <div key={i} className="bg-white p-8 rounded-2xl border border-gray-200 text-center shadow-sm hover:shadow-md transition-all">
                <item.icon className="h-10 w-10 text-amber-500 mx-auto mb-4" />
                <h3 className="text-xl font-bold mb-1">{item.type}</h3>
                <p className="text-xs text-gray-500 mb-4">{item.desc}</p>
                <p className="text-2xl font-bold text-gray-900">{item.price}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Other Cities Links */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h3 className="text-xl font-bold text-gray-900 mb-8">Other Cities We Serve</h3>
          <div className="flex flex-wrap gap-3">
            {cities.filter(c => c.slug !== city.slug).map(c => (
              <Link 
                key={c.slug} 
                to={`/${c.slug}-taxi`}
                className="px-4 py-2 bg-gray-100 rounded-lg text-sm font-medium text-gray-600 hover:bg-amber-400 hover:text-black transition-all"
              >
                {c.name} Taxi
              </Link>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
