import React from 'react';
import { Phone, MessageCircle, ShieldCheck, Clock, MapPin, Star, Car, Users, Zap, Heart, Award } from 'lucide-react';
import BookingForm from '../components/BookingForm';
import { cities } from '../constants/cities';
import { Link } from 'react-router-dom';
import { motion } from 'motion/react';

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="relative min-h-[600px] flex items-center bg-black overflow-hidden">
        <div className="absolute inset-0 opacity-40">
          <img 
            src="https://picsum.photos/seed/chennai/1920/1080" 
            alt="Chennai Cityscape" 
            className="w-full h-full object-cover"
            referrerPolicy="no-referrer"
          />
        </div>
        <div className="absolute inset-0 bg-gradient-to-r from-black via-black/80 to-transparent"></div>
        
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 py-16">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <motion.div 
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.6 }}
              className="text-white"
            >
              <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold font-display leading-tight mb-6">
                All Over Tamilnadu 24/7 <span className="text-amber-400">Taxi Service</span>
              </h1>
              <p className="text-xl text-gray-300 mb-8 max-w-lg">
                Airport Drop | Local Rental | Outstation | Best Price Guarantee. Fast Pickup in 10 Minutes.
              </p>
              <div className="flex flex-wrap gap-4">
                <a 
                  href="tel:8608199000" 
                  className="bg-amber-400 text-black px-8 py-4 rounded-xl font-bold text-lg flex items-center gap-2 hover:bg-amber-500 transition-all shadow-xl shadow-amber-400/20"
                >
                  <Phone className="h-5 w-5" /> Call Now
                </a>
                <a 
                  href="https://wa.me/918608199000" 
                  target="_blank"
                  className="bg-green-500 text-white px-8 py-4 rounded-xl font-bold text-lg flex items-center gap-2 hover:bg-green-600 transition-all shadow-xl shadow-green-500/20"
                >
                  <MessageCircle className="h-5 w-5" /> WhatsApp Now
                </a>
              </div>
            </motion.div>

            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="w-full max-w-md mx-auto lg:ml-auto"
            >
              <BookingForm />
            </motion.div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section id="services" className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">Our <span className="text-amber-500">Services</span></h2>
            <p className="text-gray-600 max-w-2xl mx-auto">Professional taxi services tailored to your needs across Tamil Nadu.</p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              { icon: Zap, label: "Airport Transfer", sub: "On-time pickup & drop" },
              { icon: MapPin, label: "Local Rental", sub: "Hourly & daily packages" },
              { icon: Car, label: "Outstation", sub: "One-way & round trip" },
              { icon: Award, label: "Corporate", sub: "Business travel support" }
            ].map((service, idx) => (
              <motion.div 
                key={idx}
                whileHover={{ y: -5 }}
                className="bg-gray-50 p-8 rounded-2xl border border-gray-100 text-center hover:shadow-xl transition-all"
              >
                <div className="bg-amber-100 w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6">
                  <service.icon className="h-8 w-8 text-amber-600" />
                </div>
                <h3 className="text-xl font-bold mb-2 text-gray-900">{service.label}</h3>
                <p className="text-gray-500 text-sm">{service.sub}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* City Links Section */}
      <section className="py-24 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">Our <span className="text-amber-500">Taxi Services</span> Across Tamil Nadu</h2>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-4">
            {cities.map((city) => (
              <Link 
                key={city.slug}
                to={`/${city.slug}-taxi`}
                className="bg-white p-6 rounded-xl border border-gray-200 text-center font-bold text-gray-700 hover:border-amber-400 hover:text-amber-600 transition-all shadow-sm"
              >
                {city.name} Taxi
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">Why Choose <span className="text-amber-500">OKOK Taxi?</span></h2>
            <p className="text-gray-600">Safe, verified & customer-friendly taxi service in Chennai</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              "Own Drivers Only – No Third Party Drivers",
              "All Documents Verified & Background Checked",
              "Police Verified Drivers for Safety",
              "Health Checked Drivers for Safe Travel",
              "100% Proper Driving Licence Holders",
              "Breakdown Support – Free Drop to Destination",
              "Only 5-Year New Vehicles for Comfort Ride",
              "No Comparison – Premium Quality Service",
              "Fair Pricing – Benefit for Driver & Customer",
              "Special Care for Pregnant Ladies",
              "30% Discount for Hospital Trips (Above 500 KM)",
              "10% Discount for Pregnant Women"
            ].map((reason, idx) => (
              <div key={idx} className="flex items-center gap-4 p-4 bg-gray-50 rounded-xl border border-gray-100">
                <ShieldCheck className="h-5 w-5 text-green-500 flex-shrink-0" />
                <span className="text-sm font-medium text-gray-700">{reason}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Fleet Section */}
      <section id="fleet" className="py-24 bg-black text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold mb-4">Our <span className="text-amber-400">Fleet</span></h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { type: "Sedan", models: "Swift Dzire / Etios", price: "From ₹12/km", icon: Car },
              { type: "SUV", models: "Ertiga / XUV", price: "From ₹16/km", icon: Car },
              { type: "Innova", models: "Innova Crysta", price: "From ₹18/km", icon: Car }
            ].map((car, idx) => (
              <div key={idx} className="bg-white/5 border border-white/10 p-8 rounded-2xl text-center hover:bg-white/10 transition-all">
                <car.icon className="h-12 w-12 text-amber-400 mx-auto mb-6" />
                <h3 className="text-2xl font-bold mb-2">{car.type}</h3>
                <p className="text-gray-400 mb-4">{car.models}</p>
                <p className="text-amber-400 font-bold text-xl">{car.price}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Reviews Section */}
      <section id="reviews" className="py-24 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">What Our <span className="text-amber-500">Customers</span> Say</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              { name: "Priya Sharma", text: "Best taxi service in Chennai! The driver arrived in just 8 minutes. Very clean car and polite driver. Will definitely book again." },
              { name: "Rajesh Kumar", text: "Used OKOK Taxi for airport drop. Price was very reasonable compared to others. GPS tracking gave me peace of mind. Highly recommended!" },
              { name: "Anitha Rajan", text: "Booked an outstation trip to Pondicherry. Smooth ride, professional driver, and transparent billing. 5 stars all the way!" }
            ].map((review, idx) => (
              <div key={idx} className="bg-gray-50 p-8 rounded-2xl border border-gray-100 italic">
                <div className="flex text-amber-400 mb-4">
                  {[...Array(5)].map((_, i) => <Star key={i} className="h-4 w-4 fill-current" />)}
                </div>
                <p className="text-gray-600 mb-6">"{review.text}"</p>
                <p className="text-gray-900 font-bold not-italic">— {review.name}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
