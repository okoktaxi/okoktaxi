import React, { useState } from 'react';
import { Phone, User, MapPin, Calendar, Clock, Car } from 'lucide-react';

export default function BookingForm() {
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    pickup: '',
    drop: '',
    date: '',
    time: '',
    service: ''
  });

  const [phoneError, setPhoneError] = useState('');

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { id, value } = e.target;
    
    if (id === 'phone') {
      const cleaned = value.replace(/\D/g, '').slice(0, 10);
      setFormData(prev => ({ ...prev, phone: cleaned }));
      if (cleaned.length > 0 && cleaned.length < 10) {
        setPhoneError('Please enter a valid 10-digit mobile number');
      } else {
        setPhoneError('');
      }
    } else {
      setFormData(prev => ({ ...prev, [id]: value }));
    }
  };

  const handleBooking = (e: React.FormEvent) => {
    e.preventDefault();
    const { name, phone, pickup, drop, date, time, service } = formData;

    if (!name || !phone || !pickup || !drop || !date || !time || !service) {
      alert("Please fill all details");
      return;
    }

    if (phone.length !== 10) {
      setPhoneError('Please enter a valid 10-digit mobile number');
      return;
    }

    const message = `New Booking Request:
Name: ${name}
Phone: ${phone}
Pickup: ${pickup}
Drop: ${drop}
Date: ${date}
Time: ${time}
Service: ${service}`;

    const whatsappURL = `https://wa.me/918608199000?text=${encodeURIComponent(message)}`;
    window.open(whatsappURL, "_blank");
  };

  return (
    <div className="bg-white rounded-2xl p-6 shadow-2xl border border-gray-100">
      <h3 className="text-xl font-bold text-center mb-6 text-gray-900">Book Your Ride Now</h3>
      <form onSubmit={handleBooking} className="space-y-4">
        <div className="relative">
          <User className="absolute left-3 top-3.5 h-4 w-4 text-gray-400" />
          <input
            type="text"
            id="name"
            placeholder="Your Name"
            required
            className="w-full pl-10 pr-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-amber-400 focus:border-transparent outline-none transition-all"
            value={formData.name}
            onChange={handleChange}
          />
        </div>

        <div className="relative">
          <Phone className="absolute left-3 top-3.5 h-4 w-4 text-gray-400" />
          <input
            type="tel"
            id="phone"
            placeholder="10-digit Mobile Number"
            maxLength={10}
            required
            className="w-full pl-10 pr-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-amber-400 focus:border-transparent outline-none transition-all"
            value={formData.phone}
            onChange={handleChange}
          />
          {phoneError && <p className="text-red-500 text-xs mt-1 ml-1">{phoneError}</p>}
        </div>

        <div className="relative">
          <MapPin className="absolute left-3 top-3.5 h-4 w-4 text-gray-400" />
          <input
            type="text"
            id="pickup"
            placeholder="Pickup Location"
            required
            className="w-full pl-10 pr-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-amber-400 focus:border-transparent outline-none transition-all"
            value={formData.pickup}
            onChange={handleChange}
          />
        </div>

        <div className="relative">
          <MapPin className="absolute left-3 top-3.5 h-4 w-4 text-gray-400" />
          <input
            type="text"
            id="drop"
            placeholder="Drop Location"
            required
            className="w-full pl-10 pr-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-amber-400 focus:border-transparent outline-none transition-all"
            value={formData.drop}
            onChange={handleChange}
          />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="relative">
            <Calendar className="absolute left-3 top-3.5 h-4 w-4 text-gray-400" />
            <input
              type="date"
              id="date"
              required
              className="w-full pl-10 pr-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-amber-400 focus:border-transparent outline-none transition-all text-sm"
              value={formData.date}
              onChange={handleChange}
            />
          </div>
          <div className="relative">
            <Clock className="absolute left-3 top-3.5 h-4 w-4 text-gray-400" />
            <input
              type="time"
              id="time"
              required
              className="w-full pl-10 pr-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-amber-400 focus:border-transparent outline-none transition-all text-sm"
              value={formData.time}
              onChange={handleChange}
            />
          </div>
        </div>

        <div className="relative">
          <Car className="absolute left-3 top-3.5 h-4 w-4 text-gray-400" />
          <select
            id="service"
            required
            className="w-full pl-10 pr-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-amber-400 focus:border-transparent outline-none transition-all appearance-none bg-white"
            value={formData.service}
            onChange={handleChange}
          >
            <option value="">Select Service</option>
            <option value="Local Rental">Local Rental</option>
            <option value="Airport(Pickup/Drop)">Airport(Pickup/Drop)</option>
            <option value="One Way">One Way</option>
            <option value="Round Trip">Round Trip</option>
          </select>
        </div>

        <button
          type="submit"
          className="w-full bg-gradient-to-r from-amber-400 to-amber-600 text-black font-bold py-4 rounded-xl shadow-lg hover:shadow-xl hover:-translate-y-0.5 transition-all active:scale-95"
        >
          Get Estimate via WhatsApp
        </button>
      </form>
    </div>
  );
}
