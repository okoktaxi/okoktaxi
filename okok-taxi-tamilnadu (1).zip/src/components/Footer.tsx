import React from 'react';
import { Instagram, Facebook, Youtube, Send, MessageCircle, Phone } from 'lucide-react';
import { Link } from 'react-router-dom';
import { cities } from '../constants/cities';

export default function Footer() {
  return (
    <footer className="bg-black text-gray-400 pt-16 pb-24 md:pb-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-12">
          <div className="col-span-1 md:col-span-2">
            <div className="flex items-center gap-3 mb-6">
              <div className="bg-amber-400 p-1.5 rounded-lg">
                <img 
                  src="https://picsum.photos/seed/taxi/100/100" 
                  alt="OKOK Taxi Logo" 
                  className="h-8 w-8 rounded object-cover"
                  referrerPolicy="no-referrer"
                />
              </div>
              <span className="text-2xl font-bold text-white tracking-tight">OKOK <span className="text-amber-400">Taxi</span></span>
            </div>
            <p className="text-sm leading-relaxed mb-6 max-w-md">
              Tamil Nadu's most trusted 24/7 taxi service. We provide fast, reliable, and affordable transportation for airport transfers, outstation trips, and local rentals.
            </p>
            <div className="flex gap-4">
              <a href="https://www.instagram.com/okoktaxi.official/" target="_blank" className="hover:text-amber-400 transition-colors"><Instagram className="h-5 w-5" /></a>
              <a href="https://www.facebook.com/profile.php?id=61587548716432" target="_blank" className="hover:text-amber-400 transition-colors"><Facebook className="h-5 w-5" /></a>
              <a href="https://www.youtube.com/channel/UCkfGFPStbBZ88aD5TmWr2ew" target="_blank" className="hover:text-amber-400 transition-colors"><Youtube className="h-5 w-5" /></a>
              <a href="https://t.me/okoktaxi" target="_blank" className="hover:text-amber-400 transition-colors"><Send className="h-5 w-5" /></a>
            </div>
          </div>

          <div>
            <h4 className="text-white font-bold mb-6">Quick Links</h4>
            <ul className="space-y-4 text-sm">
              <li><Link to="/" className="hover:text-amber-400 transition-colors">Home</Link></li>
              <li><a href="#services" className="hover:text-amber-400 transition-colors">Our Services</a></li>
              <li><a href="#fleet" className="hover:text-amber-400 transition-colors">Our Fleet</a></li>
              <li><a href="#reviews" className="hover:text-amber-400 transition-colors">Customer Reviews</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-bold mb-6">City Services</h4>
            <ul className="space-y-4 text-sm">
              {cities.map(city => (
                <li key={city.slug}>
                  <Link to={`/${city.slug}-taxi`} className="hover:text-amber-400 transition-colors">
                    {city.name} Taxi
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-800 pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-xs">
          <p>© 2026 OKOK Taxi. All rights reserved.</p>
          <div className="flex items-center gap-6">
            <a href="tel:8608199000" className="flex items-center gap-2 hover:text-white transition-colors">
              <Phone className="h-3 w-3" /> 8608199000
            </a>
            <p>Available 24/7 Across Tamil Nadu</p>
          </div>
        </div>
      </div>

      {/* Sticky Mobile CTA */}
      <div className="fixed bottom-0 left-0 right-0 md:hidden bg-black p-3 flex gap-3 z-50 border-t border-gray-800">
        <a 
          href="tel:8608199000" 
          className="flex-1 bg-gradient-to-r from-amber-400 to-amber-600 text-black py-3 rounded-xl font-bold text-sm flex items-center justify-center gap-2 shadow-lg"
        >
          <Phone className="h-4 w-4" /> Call Now
        </a>
        <a 
          href="https://wa.me/918608199000" 
          className="flex-1 bg-green-500 text-white py-3 rounded-xl font-bold text-sm flex items-center justify-center gap-2 shadow-lg"
        >
          <MessageCircle className="h-4 w-4" /> WhatsApp
        </a>
      </div>
    </footer>
  );
}
