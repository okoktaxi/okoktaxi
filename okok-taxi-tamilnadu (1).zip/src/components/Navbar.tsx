import React from 'react';
import { Phone, MessageCircle } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function Navbar() {
  return (
    <nav className="bg-black text-white sticky top-0 z-50 shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16 sm:h-20">
          <Link to="/" className="flex items-center gap-3 group">
            <div className="bg-amber-400 p-1.5 rounded-lg group-hover:scale-105 transition-transform">
              <img 
                src="https://picsum.photos/seed/taxi/100/100" 
                alt="OKOK Taxi Logo" 
                className="h-8 w-8 sm:h-10 sm:w-10 rounded object-cover"
                referrerPolicy="no-referrer"
              />
            </div>
            <span className="text-xl sm:text-2xl font-bold tracking-tight">OKOK <span className="text-amber-400">Taxi</span></span>
          </Link>

          <div className="hidden md:flex items-center gap-8">
            <Link to="/" className="text-sm font-medium hover:text-amber-400 transition-colors">Home</Link>
            <a href="#services" className="text-sm font-medium hover:text-amber-400 transition-colors">Services</a>
            <a href="#fleet" className="text-sm font-medium hover:text-amber-400 transition-colors">Fleet</a>
            <a href="#reviews" className="text-sm font-medium hover:text-amber-400 transition-colors">Reviews</a>
          </div>

          <div className="flex items-center gap-3">
            <a 
              href="tel:8608199000" 
              className="bg-gradient-to-r from-amber-400 to-amber-600 text-black px-4 py-2 rounded-lg font-bold text-sm flex items-center gap-2 hover:shadow-lg hover:-translate-y-0.5 transition-all"
            >
              <Phone className="h-4 w-4" />
              <span className="hidden sm:inline">8608199000</span>
              <span className="sm:hidden">Call</span>
            </a>
          </div>
        </div>
      </div>
    </nav>
  );
}
