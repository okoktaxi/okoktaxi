export interface CityData {
  slug: string;
  name: string;
  title: string;
  description: string;
  keywords: string[];
}

export const cities: CityData[] = [
  {
    slug: 'chennai',
    name: 'Chennai',
    title: 'OKOK Taxi Chennai – Fast & Reliable 24/7 Taxi Service',
    description: "Book Chennai's most trusted taxi service. Airport drop, outstation cabs, local rental at best prices. Fast pickup in 10 minutes. Call 8608199000.",
    keywords: [
      'cab services in chennai', 'chennai taxi service', 'call taxi chennai', 'chennai cabs', 
      'taxi chennai', 'cab booking chennai', 'taxi booking chennai', 'chennai cab booking', 
      'chennai to pondicherry cab', 'chennai to pondicherry taxi', 'chennai city taxi', 
      'taxi from chennai to pondicherry', 'drop taxi chennai', 'call taxi', 'one way taxi', 
      'cab booking', 'outstation cabs', 'drop taxi'
    ]
  },
  {
    slug: 'coimbatore',
    name: 'Coimbatore',
    title: 'OKOK Taxi Coimbatore – 24/7 Airport & Outstation Cabs',
    description: 'Reliable taxi service in Coimbatore. Airport transfers, outstation trips, and local rentals at affordable rates. Call 8608199000.',
    keywords: [
      'coimbatore red taxi phone number', 'coimbatore taxi', 'coimbatore cabs', 'taxi in coimbatore', 
      'call taxi in coimbatore', 'cabs in coimbatore', 'taxi service in coimbatore', 
      'coimbatore cab service', 'coimbatore taxi number', 'drop taxi coimbatore', 
      'coimbatore taxi service', 'covai taxi', 'kovai taxi', 'taxi to coimbatore', 
      'covai call taxi', 'ola cabs coimbatore', 'ola taxi coimbatore', 'call taxi', 
      'one way taxi', 'outstation taxi'
    ]
  },
  {
    slug: 'madurai',
    name: 'Madurai',
    title: 'OKOK Taxi Madurai – Trusted Local & Outstation Taxi',
    description: 'Best taxi service in Madurai for airport drops and long distance travel. Professional drivers and clean cars. Call 8608199000.',
    keywords: [
      'taxi service in madurai', 'madurai call taxi', 'madurai cab service', 'drop taxi madurai', 
      'best track madurai', 'ola cabs in madurai', 'call taxi', 'one way taxi', 'outstation cabs', 
      'cab service near me'
    ]
  },
  {
    slug: 'trichy',
    name: 'Trichy',
    title: 'OKOK Taxi Trichy – 24/7 Airport Drop & Outstation',
    description: 'Trichy taxi service for airport transfers and outstation travel. Fast pickup and transparent pricing. Call 8608199000.',
    keywords: [
      'drop taxi in trichy', 'trichy taxi', 'trichy cab service', 'taxi service in trichy', 
      'trichy cabs', 'drop taxi trichy', 'call taxi', 'one way taxi', 'outstation taxi', 
      'trichy cab booking'
    ]
  },
  {
    slug: 'tirunelveli',
    name: 'Tirunelveli',
    title: 'OKOK Taxi Tirunelveli – Reliable Local & Outstation Cabs',
    description: 'Book your taxi in Tirunelveli for safe and comfortable travel. 24/7 support and professional drivers. Call 8608199000.',
    keywords: [
      'call taxi in tirunelveli', 'cabs in tirunelveli', 'taxi in tirunelveli', 'nellai call taxi', 
      'taxi tirunelveli', 'tirunelveli cabs', 'tirunelveli taxi', 'tirunelveli cab', 
      'cabs tirunelveli', 'call taxi', 'one way taxi', 'outstation cabs'
    ]
  },
  {
    slug: 'pondicherry',
    name: 'Pondicherry',
    title: 'OKOK Taxi Pondicherry – Best Cabs for Local & Outstation',
    description: 'Safe and reliable taxi service in Pondicherry. Perfect for tourists and local travel. Call 8608199000.',
    keywords: [
      'cab service in pondicherry', 'taxi service in pondicherry', 'pondicherry cabs', 
      'pondicherry taxi', 'cab to pondicherry', 'taxi to pondicherry', 'call taxi', 
      'one way taxi', 'outstation taxi', 'pondicherry cab booking'
    ]
  },
  {
    slug: 'hosur',
    name: 'Hosur',
    title: 'OKOK Taxi Hosur – 24/7 Local & Outstation Cabs',
    description: 'Reliable taxi service in Hosur. Best rates for local and outstation trips. Call 8608199000.',
    keywords: ['call taxi in hosur', 'hosur taxi', 'hosur cabs', 'hosur call taxi', 'best taxi hosur']
  },
  {
    slug: 'vellore',
    name: 'Vellore',
    title: 'OKOK Taxi Vellore – Trusted Taxi Service',
    description: 'Book your taxi in Vellore for safe travel. 24/7 availability. Call 8608199000.',
    keywords: ['call taxi vellore', 'taxi service in vellore', 'cab service in vellore', 'vellore taxi cab service']
  },
  {
    slug: 'salem',
    name: 'Salem',
    title: 'OKOK Taxi Salem – Fast & Reliable Cabs',
    description: 'Professional taxi service in Salem. Local and outstation trips at best prices. Call 8608199000.',
    keywords: ['call taxi in salem', 'salem taxi', 'salem call taxi']
  },
  {
    slug: 'erode',
    name: 'Erode',
    title: 'OKOK Taxi Erode – 24/7 Cab Service',
    description: 'Reliable cabs in Erode for all your travel needs. Call 8608199000.',
    keywords: ['call taxi erode', 'erode red taxi number', 'erode taxi']
  },
  {
    slug: 'karur',
    name: 'Karur',
    title: 'OKOK Taxi Karur – Best Local & Outstation Taxi',
    description: 'Safe and affordable taxi service in Karur. Call 8608199000.',
    keywords: ['call taxi karur', 'karur taxi', 'karur call taxi']
  },
  {
    slug: 'dharmapuri',
    name: 'Dharmapuri',
    title: 'OKOK Taxi Dharmapuri – 24/7 Taxi Service',
    description: 'Book your taxi in Dharmapuri for comfortable travel. Call 8608199000.',
    keywords: ['dharmapuri call taxi', 'call taxi dharmapuri', 'dharmapuri taxi']
  }
];
